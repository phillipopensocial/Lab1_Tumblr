//: Playground - noun: a place where people can play

import SwiftyJSON
